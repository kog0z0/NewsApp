export { QuickStartPage } from "@bundle:com.huawei.quickstart/default@quickstart/ets/pages/QuickStartPage";
