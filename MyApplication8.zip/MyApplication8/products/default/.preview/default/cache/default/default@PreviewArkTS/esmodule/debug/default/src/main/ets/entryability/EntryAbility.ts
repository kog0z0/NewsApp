import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import AbilityConstant from "@ohos:app.ability.AbilityConstant";
import bundleManager from "@ohos:bundle.bundleManager";
import type { Permissions as Permissions } from "@ohos:abilityAccessCtrl";
import UIAbility from "@ohos:app.ability.UIAbility";
import type Want from "@ohos:app.ability.Want";
import hilog from "@ohos:hilog";
import type window from "@ohos:window";
import type { BusinessError as BusinessError } from "@ohos:base";
const TAG: string = 'EntryAbility';
export default class EntryAbility extends UIAbility {
    onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
        this.checkPermissions();
        if (launchParam.launchReason === AbilityConstant.LaunchReason.CONTINUATION) {
            this.context.restoreWindowStage(new LocalStorage());
        }
    }
    async checkPermissions(): Promise<void> {
        const permissions: Array<Permissions> = ['ohos.permission.DISTRIBUTED_DATASYNC'];
        const accessManager = abilityAccessCtrl.createAtManager();
        try {
            const bundleFlags = bundleManager.BundleFlag.GET_BUNDLE_INFO_WITH_APPLICATION;
            const bundleInfo = await bundleManager.getBundleInfoForSelf(bundleFlags);
            const grantStatus = await accessManager.checkAccessToken(bundleInfo.appInfo.accessTokenId, permissions[0]);
            if (grantStatus === abilityAccessCtrl.GrantStatus.PERMISSION_DENIED) {
                accessManager.requestPermissionsFromUser(this.context, permissions);
            }
        }
        catch (err) {
            console.error('EntryAbility', 'checkPermissions', `Catch err: ${err}`);
            return;
        }
    }
    onContinue(wantParam: Record<string, Object>): AbilityConstant.OnContinueResult | Promise<AbilityConstant.OnContinueResult> {
        return AbilityConstant.OnContinueResult.AGREE;
    }
    onDestroy(): void {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage): void {
        // Main window is created, set main page for this ability
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');
        requestFullScreen(windowStage, this.context);
        windowStage.loadContent('pages/Index', (err, data) => {
            if (err.code) {
                hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', JSON.stringify(err) ?? '');
                return;
            }
            let windowClass = windowStage.getMainWindowSync();
            AppStorage.setOrCreate('UIContext', windowClass.getUIContext());
            hilog.info(0x0000, 'testTag', 'Succeeded in loading the content. Data: %{public}s', JSON.stringify(data) ?? '');
        });
    }
    onWindowStageDestroy(): void {
        // Main window is destroyed, release UI related resources
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground(): void {
        // Ability has brought to foreground
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground(): void {
        // Ability has back to background
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
}
function requestFullScreen(windowStage: window.WindowStage, context: Context): void {
    windowStage.getMainWindow((err: BusinessError, data: window.Window) => {
        if (err.code) {
            return;
        }
        let windowClass: window.Window = data;
        windowClass.setWindowLayoutFullScreen(true);
    });
}
