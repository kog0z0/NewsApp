if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Header_Params {
    message?: string;
    isPlaying?: boolean;
    speaker?: Speaker;
    content?: string;
}
import emitter from "@ohos:events.emitter";
import { Speaker } from "@bundle:com.huawei.quickstart/default@utils/Index";
export class Header extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('快速入门', this, "message");
        this.__isPlaying = new ObservedPropertySimplePU(false, this, "isPlaying");
        this.speaker = new Speaker();
        this.content = '余承东邀请你开启鸿蒙体验之旅 欢迎来到HarmonyOS世界';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Header_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.isPlaying !== undefined) {
            this.isPlaying = params.isPlaying;
        }
        if (params.speaker !== undefined) {
            this.speaker = params.speaker;
        }
        if (params.content !== undefined) {
            this.content = params.content;
        }
    }
    updateStateVars(params: Header_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__isPlaying.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__isPlaying.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __isPlaying: ObservedPropertySimplePU<boolean>;
    get isPlaying() {
        return this.__isPlaying.get();
    }
    set isPlaying(newValue: boolean) {
        this.__isPlaying.set(newValue);
    }
    private speaker: Speaker;
    private content: string;
    aboutToAppear(): void {
        emitter.on('eventId', () => {
            this.isPlaying = false;
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("features/quickstart/src/main/ets/view/Header.ets(18:5)", "quickstart");
            Row.padding({
                left: 16,
                right: 16
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.height(56);
            Row.margin({
                bottom: 11
            });
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.message);
            Text.debugLine("features/quickstart/src/main/ets/view/Header.ets(19:7)", "quickstart");
            Text.fontFamily('HarmonyHeiTi-Bold');
            Text.fontSize(24);
            Text.textAlign(TextAlign.Start);
            Text.lineHeight(33);
            Text.fontWeight(700);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.isPlaying ? { "id": 16777243, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" } : { "id": 16777251, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
            Image.debugLine("features/quickstart/src/main/ets/view/Header.ets(26:7)", "quickstart");
            Image.width(40);
            Image.height(40);
            Image.onClick(() => {
                this.isPlaying = !this.isPlaying;
                if (this.isPlaying === true) {
                    this.speaker.startSpeak(this.content);
                }
                else {
                    this.speaker.stopSpeak();
                }
            });
        }, Image);
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
