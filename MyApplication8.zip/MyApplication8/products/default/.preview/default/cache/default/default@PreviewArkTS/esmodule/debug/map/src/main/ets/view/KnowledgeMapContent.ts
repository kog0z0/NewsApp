if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface KnowledgeMapContent_Params {
    section?: Section;
    scroller?: Scroller;
    currentBreakpoint?: string;
}
import { BreakpointType, BreakpointTypeEnum } from "@bundle:com.huawei.quickstart/default@utils/Index";
interface KnowledgeBaseItem {
    type: string;
    title: string;
}
interface Material {
    subtitle: string;
    knowledgeBase: KnowledgeBaseItem[];
}
export interface Section {
    title: string;
    brief: string;
    materials: Material[];
}
const TypeMapIcon: Record<string, string> = {
    '指南': 'app.media.ic_guide',
    '准备': 'app.media.ic_prepare',
    '学习与获取证书': 'app.media.ic_medals',
    '视频教程': 'app.media.ic_video',
};
export class KnowledgeMapContent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__section = new SynchedPropertyObjectOneWayPU(params.section, this, "section");
        this.scroller = new Scroller();
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', BreakpointTypeEnum.MD, "currentBreakpoint");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: KnowledgeMapContent_Params) {
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
    }
    updateStateVars(params: KnowledgeMapContent_Params) {
        this.__section.reset(params.section);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__section.purgeDependencyOnElmtId(rmElmtId);
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__section.aboutToBeDeleted();
        this.__currentBreakpoint.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __section: SynchedPropertySimpleOneWayPU<Section>;
    get section() {
        return this.__section.get();
    }
    set section(newValue: Section) {
        this.__section.set(newValue);
    }
    private scroller: Scroller;
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    KnowledgeBlockLine(knowledgeBaseItem: KnowledgeBaseItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(34:5)", "map");
            Row.width('100%');
            Row.height(64);
            Row.alignItems(VerticalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": -1, "type": -1, params: [TypeMapIcon[knowledgeBaseItem.type]], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
            Image.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(35:7)", "map");
            Image.width(20);
            Image.height(20);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(39:7)", "map");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 18 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(knowledgeBaseItem.title);
            Text.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(40:9)", "map");
            Text.fontFamily('HarmonyHeiTi-Medium');
            Text.fontSize(16);
            Text.fontWeight(500);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(knowledgeBaseItem.type);
            Text.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(44:9)", "map");
            Text.fontFamily('HarmonyHeiTi');
            Text.fontSize(14);
            Text.fontWeight(400);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(52:7)", "map");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777266, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
            Image.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(54:7)", "map");
            Image.width(12);
            Image.height(24);
        }, Image);
        Row.pop();
    }
    KnowledgeBlock(material: Material, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(65:5)", "map");
            Column.width('100%');
            Column.margin({ top: 28 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(material.subtitle);
            Text.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(66:7)", "map");
            Text.fontFamily('HarmonyHeiTi-Medium');
            Text.fontSize(14);
            Text.fontWeight(500);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 12 });
            List.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(72:7)", "map");
            List.lanes(new BreakpointType<number>({ sm: 1, md: 1, lg: 2, xl: 2 }).getValue(this.currentBreakpoint));
            List.backgroundColor(Color.White);
            List.borderRadius(16);
            List.padding({ left: 12, right: 12 });
            List.divider({
                strokeWidth: 0.5,
                startMargin: 38,
                endMargin: 0,
                color: '#F2F2F2'
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.KnowledgeBlockLine.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, material.knowledgeBase, forEachItemGenFunction, (item: KnowledgeBaseItem, index: number) => item.title + index, true, true);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create(this.scroller);
                    Scroll.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(95:7)", "map");
                    Scroll.align(Alignment.TopStart);
                    Scroll.constraintSize({ minHeight: '100%' });
                    Scroll.edgeEffect(EdgeEffect.Spring);
                    Scroll.scrollable(ScrollDirection.Vertical);
                    Scroll.scrollBar(BarState.Auto);
                    Scroll.backgroundColor('#F1F3F5');
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(96:9)", "map");
                    Column.padding({
                        left: 24,
                        top: 12,
                        right: 24,
                        bottom: 12
                    });
                    Column.alignItems(HorizontalAlign.Start);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.section?.title);
                    Text.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(97:11)", "map");
                    Text.fontFamily('HarmonyHeiTi-Bold');
                    Text.fontSize(20);
                    Text.fontWeight(700);
                    Text.fontColor(Color.Black);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.section?.brief);
                    Text.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(103:11)", "map");
                    Text.fontFamily('HarmonyHeiTi');
                    Text.fontSize(12);
                    Text.fontColor('rgba(0,0,0,0.60)');
                    Text.textAlign(TextAlign.JUSTIFY);
                    Text.fontWeight(400);
                    Text.margin({ top: 12 });
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const material = _item;
                        this.KnowledgeBlock.bind(this)(material);
                    };
                    this.forEachUpdateFunction(elmtId, this.section?.materials, forEachItemGenFunction, (material: Material, index: number) => material.subtitle + index, false, true);
                }, ForEach);
                ForEach.pop();
                Column.pop();
                Scroll.pop();
            }, { moduleName: "default", pagePath: "features/map/src/main/ets/view/KnowledgeMapContent" });
            NavDestination.hideTitleBar(true);
            NavDestination.debugLine("features/map/src/main/ets/view/KnowledgeMapContent.ets(94:5)", "map");
        }, NavDestination);
        NavDestination.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
