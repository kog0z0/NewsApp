export { CourseLearning } from "@bundle:com.huawei.quickstart/default@learning/ets/pages/CourseLearning";
