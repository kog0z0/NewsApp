export { KnowledgeMap } from "@bundle:com.huawei.quickstart/default@map/ets/pages/KnowledgeMap";
