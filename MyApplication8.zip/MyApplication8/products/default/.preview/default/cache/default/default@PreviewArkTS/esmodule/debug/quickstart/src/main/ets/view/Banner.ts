if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Banner_Params {
    articlePathStack?: NavPathStack;
    currentBreakpoint?: string;
    bannerList?: BannerClass[];
}
import { BreakpointType, BreakpointTypeEnum } from "@bundle:com.huawei.quickstart/default@utils/Index";
import type { BannerClass } from '../model/BannerClass';
import { bufferToString } from "@bundle:com.huawei.quickstart/default@quickstart/ets/util/bufferUtil";
export class Banner extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__articlePathStack = this.initializeConsume('articlePathStack', "articlePathStack");
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', BreakpointTypeEnum.MD, "currentBreakpoint");
        this.__bannerList = new ObservedPropertyObjectPU([], this, "bannerList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Banner_Params) {
        if (params.bannerList !== undefined) {
            this.bannerList = params.bannerList;
        }
    }
    updateStateVars(params: Banner_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__articlePathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
        this.__bannerList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__articlePathStack.aboutToBeDeleted();
        this.__currentBreakpoint.aboutToBeDeleted();
        this.__bannerList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __articlePathStack: ObservedPropertyAbstractPU<NavPathStack>;
    get articlePathStack() {
        return this.__articlePathStack.get();
    }
    set articlePathStack(newValue: NavPathStack) {
        this.__articlePathStack.set(newValue);
    }
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    private __bannerList: ObservedPropertyObjectPU<BannerClass[]>;
    get bannerList() {
        return this.__bannerList.get();
    }
    set bannerList(newValue: BannerClass[]) {
        this.__bannerList.set(newValue);
    }
    aboutToAppear(): void {
        this.getBannerDataFromJSON();
    }
    getBannerDataFromJSON() {
        this.getUIContext().getHostContext()?.resourceManager.getRawFileContent('BannerData.json').then(value => {
            this.bannerList = JSON.parse(bufferToString(value)) as BannerClass[];
        });
    }
    clickToDetailPage(item: BannerClass) {
        this.articlePathStack.pushPathByName('bannerDetailPage', item);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create();
            Swiper.debugLine("features/quickstart/src/main/ets/view/Banner.ets(26:5)", "quickstart");
            Swiper.displayCount(new BreakpointType({ sm: 1, md: 2, lg: 2 }).getValue(this.currentBreakpoint));
            Swiper.displayMode(SwiperDisplayMode.STRETCH);
            Swiper.indicator(this.currentBreakpoint === BreakpointTypeEnum.SM ?
                Indicator.dot().
                    color('#1a000000').
                    selectedColor('#0A59F7') :
                false);
            Swiper.nextMargin(new BreakpointType<Length>({ sm: 0, md: 12, lg: 266 }).getValue(this.currentBreakpoint));
            Swiper.autoPlay(true);
            Swiper.loop(true);
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": -1, "type": -1, params: [item.imageSrc], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
                    Image.debugLine("features/quickstart/src/main/ets/view/Banner.ets(28:9)", "quickstart");
                    Image.objectFit(ImageFit.Contain);
                    Image.width('100%');
                    Image.borderRadius(16);
                    Image.padding({ top: 11, left: 16, right: 16 });
                    Image.onClick(() => {
                        this.clickToDetailPage(item);
                    });
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.bannerList, forEachItemGenFunction, (item: BannerClass) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Swiper.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
