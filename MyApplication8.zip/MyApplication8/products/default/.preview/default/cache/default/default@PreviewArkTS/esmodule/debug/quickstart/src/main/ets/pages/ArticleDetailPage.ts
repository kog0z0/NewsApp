if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WebComponent_Params {
    articleDetail?: ArticleClass | null;
    webviewController?: WebviewController;
}
interface ArticleDetailPage_Params {
    webviewController?: webview.WebviewController;
    articlePathStack?: NavPathStack;
    articleDetail?: ArticleClass | null;
    isClicked?: boolean;
    speaker?: Speaker;
}
import webview from "@ohos:web.webview";
import type { ArticleClass } from '../model/ArticleClass';
import emitter from "@ohos:events.emitter";
import { Speaker } from "@bundle:com.huawei.quickstart/default@utils/Index";
export class ArticleDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__webviewController = new ObservedPropertyObjectPU(new webview.WebviewController, this, "webviewController");
        this.__articlePathStack = this.initializeConsume('articlePathStack', "articlePathStack");
        this.__articleDetail = new ObservedPropertyObjectPU(null, this, "articleDetail");
        this.__isClicked = new ObservedPropertySimplePU(false, this, "isClicked");
        this.speaker = new Speaker();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ArticleDetailPage_Params) {
        if (params.webviewController !== undefined) {
            this.webviewController = params.webviewController;
        }
        if (params.articleDetail !== undefined) {
            this.articleDetail = params.articleDetail;
        }
        if (params.isClicked !== undefined) {
            this.isClicked = params.isClicked;
        }
        if (params.speaker !== undefined) {
            this.speaker = params.speaker;
        }
    }
    updateStateVars(params: ArticleDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__webviewController.purgeDependencyOnElmtId(rmElmtId);
        this.__articlePathStack.purgeDependencyOnElmtId(rmElmtId);
        this.__articleDetail.purgeDependencyOnElmtId(rmElmtId);
        this.__isClicked.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__webviewController.aboutToBeDeleted();
        this.__articlePathStack.aboutToBeDeleted();
        this.__articleDetail.aboutToBeDeleted();
        this.__isClicked.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __webviewController: ObservedPropertyObjectPU<webview.WebviewController>;
    get webviewController() {
        return this.__webviewController.get();
    }
    set webviewController(newValue: webview.WebviewController) {
        this.__webviewController.set(newValue);
    }
    private __articlePathStack: ObservedPropertyAbstractPU<NavPathStack>;
    get articlePathStack() {
        return this.__articlePathStack.get();
    }
    set articlePathStack(newValue: NavPathStack) {
        this.__articlePathStack.set(newValue);
    }
    private __articleDetail: ObservedPropertyObjectPU<ArticleClass | null>;
    get articleDetail() {
        return this.__articleDetail.get();
    }
    set articleDetail(newValue: ArticleClass | null) {
        this.__articleDetail.set(newValue);
    }
    private __isClicked: ObservedPropertySimplePU<boolean>;
    get isClicked() {
        return this.__isClicked.get();
    }
    set isClicked(newValue: boolean) {
        this.__isClicked.set(newValue);
    }
    private speaker: Speaker;
    aboutToAppear(): void {
        this.articleDetail = this.articlePathStack.getParamByName('articleDetail')[0] as ArticleClass;
        emitter.on("eventId", () => {
            this.isClicked = false;
        });
    }
    aboutToDisappear(): void {
        this.speaker?.shutdownEngine();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            NavDestination.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(27:7)", "quickstart");
                    Column.padding({ left: 16, right: 16 });
                    Column.width('100%');
                    Column.height('100%');
                    Column.justifyContent(FlexAlign.SpaceBetween);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(28:9)", "quickstart");
                    Row.justifyContent(FlexAlign.SpaceBetween);
                    Row.width('100%');
                    Row.height(56);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(29:11)", "quickstart");
                    Row.width('80%');
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777263, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
                    Image.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(30:13)", "quickstart");
                    Image.width(40);
                    Image.height(40);
                    Image.onClick(() => {
                        this.articlePathStack.pop();
                    });
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(36:13)", "quickstart");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.articleDetail?.title);
                    Text.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(37:15)", "quickstart");
                    Text.fontFamily('HarmonyHeiTi-Bold');
                    Text.fontSize(20);
                    Text.textAlign(TextAlign.Start);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.maxLines(1);
                    Text.fontWeight(700);
                    Text.margin({ left: 8 });
                }, Text);
                Text.pop();
                Row.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(this.isClicked ? { "id": 16777243, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" } : { "id": 16777251, "type": 20000, params: [], "bundleName": "com.huawei.quickstart", "moduleName": "default" });
                    Image.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(49:11)", "quickstart");
                    Image.width(40);
                    Image.height(40);
                    Image.onClick(() => {
                        this.isClicked = !this.isClicked;
                        if (this.isClicked === true) {
                            this.speaker.startSpeak(this.articleDetail!.brief);
                        }
                        else {
                            this.speaker.stopSpeak();
                        }
                    });
                }, Image);
                Row.pop();
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new WebComponent(this, { articleDetail: this.articleDetail, webviewController: this.webviewController }, undefined, elmtId, () => { }, { page: "features/quickstart/src/main/ets/pages/ArticleDetailPage.ets", line: 65, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    articleDetail: this.articleDetail,
                                    webviewController: this.webviewController
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                articleDetail: this.articleDetail, webviewController: this.webviewController
                            });
                        }
                    }, { name: "WebComponent" });
                }
                Column.pop();
            }, { moduleName: "default", pagePath: "features/quickstart/src/main/ets/pages/ArticleDetailPage" });
            NavDestination.hideTitleBar(true);
            NavDestination.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(26:5)", "quickstart");
        }, NavDestination);
        NavDestination.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class WebComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__articleDetail = new SynchedPropertyObjectOneWayPU(params.articleDetail, this, "articleDetail");
        this.__webviewController = new SynchedPropertyObjectOneWayPU(params.webviewController, this, "webviewController");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WebComponent_Params) {
    }
    updateStateVars(params: WebComponent_Params) {
        this.__articleDetail.reset(params.articleDetail);
        this.__webviewController.reset(params.webviewController);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__articleDetail.purgeDependencyOnElmtId(rmElmtId);
        this.__webviewController.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__articleDetail.aboutToBeDeleted();
        this.__webviewController.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __articleDetail: SynchedPropertySimpleOneWayPU<ArticleClass | null>;
    get articleDetail() {
        return this.__articleDetail.get();
    }
    set articleDetail(newValue: ArticleClass | null) {
        this.__articleDetail.set(newValue);
    }
    private __webviewController: SynchedPropertySimpleOneWayPU<WebviewController>;
    get webviewController() {
        return this.__webviewController.get();
    }
    set webviewController(newValue: WebviewController) {
        this.__webviewController.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(82:5)", "quickstart");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({ src: this.articleDetail?.webUrl, controller: this.webviewController });
            Web.debugLine("features/quickstart/src/main/ets/pages/ArticleDetailPage.ets(83:7)", "quickstart");
            Web.darkMode(WebDarkMode.Auto);
            Web.domStorageAccess(true);
            Web.zoomAccess(true);
            Web.fileAccess(true);
            Web.mixedMode(MixedMode.All);
            Web.cacheMode(CacheMode.None);
            Web.javaScriptAccess(true);
            Web.width('100%');
            Web.layoutWeight(1);
        }, Web);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
